# epubkit

A Python library to convert Markdown or HTML to EPUB eBooks with professional styling and features.

## Features

- Convert Markdown files to EPUB
- Convert HTML files to EPUB
- Automatic title extraction from HTML
- Support for multi-level table of contents
- Automatic image handling (download remote images, include local images)
- Professional styling based on EPUB standards
- Automatic cover generation with book title and author
- Simple API for easy usage
- Support for EPUB 3.3 specification

## Requirements

- Python 3.6+
- beautifulsoup4
- markdown
- pillow

## Installation

You can install epubkit using pip:

```bash
pip install epubkit
```

Or install from source:

```bash
git clone https://github.com/yourusername/epubkit.git
cd epubkit
pip install -e .
```

## Usage

### Convert HTML to EPUB

```python
from epubkit import HTML2EPUB

# Convert a single HTML file to EPUB
output_path = HTML2EPUB('example.html')
print(f"EPUB generated: {output_path}")

# With custom author
output_path = HTML2EPUB('example.html', author="John Doe")

# With custom output path
output_path = HTML2EPUB('example.html', output_path="my_book.epub")
```

### Convert Markdown to EPUB

```python
from epubkit import Markdown2EPUB

# Convert a single Markdown file to EPUB
output_path = Markdown2EPUB('example.md', title="My Book", author="John Doe")
print(f"EPUB generated: {output_path}")

# With custom output path
output_path = Markdown2EPUB('example.md', title="My Book", author="John Doe", output_path="my_book.epub")
```

### Using the API

```python
from epubkit import MarkdownToEPUB

# Create converter
converter = MarkdownToEPUB(title="My Book", author="John Doe")

# Add chapters
converter.add_chapter("Chapter 1", "chapter1.md")
converter.add_chapter("Chapter 2", "chapter2.md")

# Generate EPUB
output_path = "my_book.epub"
converter.generate(output_path)
print(f"EPUB generated: {output_path}")
```

## API Reference

### HTML2EPUB(html_file_path, output_path=None, author="Unknown", language="en")

Convert a single HTML file to EPUB.

- `html_file_path`: Path to the HTML file
- `output_path`: Output path for the EPUB file. If not provided, will use the title or h1 or filename
- `author`: Author name (default: "Unknown")
- `language`: Language code (default: "en")

Returns the path to the generated EPUB file.

### Markdown2EPUB(markdown_file_path, title=None, output_path=None, author="Unknown", language="en")

Convert a single Markdown file to EPUB.

- `markdown_file_path`: Path to the Markdown file
- `title`: Title of the EPUB. If not provided, will use the first heading or filename
- `output_path`: Output path for the EPUB file. If not provided, will use the title or filename
- `author`: Author name (default: "Unknown")
- `language`: Language code (default: "en")

Returns the path to the generated EPUB file.

### MarkdownToEPUB(title, author="Unknown", language="en")

Create a converter for Markdown files.

- `title`: Title of the EPUB
- `author`: Author name (default: "Unknown")
- `language`: Language code (default: "en")

### HTMLToEPUB(title=None, author="Unknown", language="en")

Create a converter for HTML files.

- `title`: Title of the EPUB. If not provided, will be extracted from HTML
- `author`: Author name (default: "Unknown")
- `language`: Language code (default: "en")

### EPUBConverter.add_chapter(title, file_path)

Add a chapter to the EPUB.

- `title`: Title of the chapter
- `file_path`: Path to the chapter file (Markdown or HTML)

### EPUBConverter.generate(output_path)

Generate the EPUB file.

- `output_path`: Path to the output EPUB file

## Project Structure

```
epubkit/
├── __init__.py          # Exports main functions and classes
├── core.py              # Core EPUB generation functionality
├── converter.py         # Converter classes for Markdown and HTML
└── utils.py             # Utility functions
```

## Testing

Run the unit tests:

```bash
python -m unittest discover tests
```

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
